package com.wolcano.musicplayer.music.mvp.models;

public class Album {

    public long id;
    public String name;
    public String artist;

    public Album(long id, String name, String artist) {

        this.id = id;
        this.name = name;
        this.artist = artist;

    }

}
