package com.wolcano.musicplayer.music.mvp.models;

public class Copy {

    public String text;
    public int icon;

    public Copy(String text, int icon) {
        this.text = text;
        this.icon = icon;
    }
}
