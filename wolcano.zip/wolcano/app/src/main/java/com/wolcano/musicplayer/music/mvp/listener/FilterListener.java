package com.wolcano.musicplayer.music.mvp.listener;

public interface FilterListener {
    void setFastScrollIndexer(boolean isShown);
}
